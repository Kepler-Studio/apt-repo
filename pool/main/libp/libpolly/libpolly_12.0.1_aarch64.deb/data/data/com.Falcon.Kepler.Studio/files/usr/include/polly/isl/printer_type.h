#ifndef ISL_PRINTER_TYPE_H
#define ISL_PRINTER_TYPE_H

#if defined(__cplusplus)
extern "C" {
#endif

struct isl_printer;
typedef struct isl_printer isl_printer;

#if defined(__cplusplus)
}
#endif

#endif
